# خطوات Supabase من الهاتف

1. افتح Supabase ثم مشروعك.
2. افتح SQL Editor ثم New Query.
3. انسخ محتوى `supabase/schema.sql` كاملًا واضغط Run.
4. افتح Table Editor ثم جدول `products`.
5. أضف المنتجات من زر Insert Row.
6. شغل المشروع في Pi App Studio.

تم وضع رابط Supabase والـ Publishable Key مباشرة داخل:

```text
lib/supabase.ts
```

إذا غيرت مشروع Supabase لاحقًا، غيّر القيمتين في نفس الملف.
