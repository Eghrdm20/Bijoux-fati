# Bijoux Fati - Pi Network App

تطبيق Next.js لعرض وبيع المجوهرات داخل Pi Browser، مع ربط Supabase للمنتجات والطلبات، وجاهز للنشر على Vercel.

## التشغيل محليًا

```bash
pnpm install
cp .env.example .env.local
pnpm dev
```

ثم افتح: http://localhost:3000

## إعداد Supabase

1. أنشئ مشروعًا جديدًا في Supabase.
2. افتح SQL Editor.
3. انسخ محتوى `supabase/schema.sql` وشغّله.
4. من Project Settings > API انسخ:
   - Project URL
   - anon public key
5. أضفهما في `.env.local` محليًا، وفي Vercel كـ Environment Variables.

## النشر على GitHub

```bash
git init
git add .
git commit -m "Initial Bijoux Fati app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/bijoux-fati.git
git push -u origin main
```

## النشر على Vercel

1. اربط مستودع GitHub بـ Vercel.
2. أضف المتغيرات:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_REQUIRE_PI_AUTH` = `false` للمعاينة أو `true` عند النشر النهائي داخل Pi Browser
3. Framework Preset: Next.js.
4. Build Command: `pnpm build`.
5. Deploy.

## ملاحظات Pi Network

- التطبيق يستخدم Pi SDK و SDKLite الموجودين في المشروع.
- `PI_NETWORK_CONFIG.SANDBOX` في `lib/system-config.ts` مضبوط حاليًا على `false` للإنتاج.
- للتجربة قبل الإطلاق يمكنك جعل `SANDBOX` = `true`.
- اجعل `NEXT_PUBLIC_REQUIRE_PI_AUTH=true` فقط عندما تريد إجبار المستخدم على الدخول عبر Pi Browser.
