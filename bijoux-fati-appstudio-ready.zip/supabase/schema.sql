create extension if not exists "pgcrypto";

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  name_en text,
  description text,
  price numeric(12, 2) not null check (price >= 0),
  image_url text,
  stock integer not null default 0 check (stock >= 0),
  rating numeric(2, 1) default 5.0,
  reviews integer default 0,
  category text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text,
  customer_phone text,
  pi_username text,
  total numeric(12, 2) not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  price numeric(12, 2) not null,
  quantity integer not null check (quantity > 0),
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products"
on public.products for select
using (is_active = true);

drop policy if exists "Public can create orders" on public.orders;
create policy "Public can create orders"
on public.orders for insert
with check (true);

drop policy if exists "Public can create order items" on public.order_items;
create policy "Public can create order items"
on public.order_items for insert
with check (true);

insert into public.products (name, name_en, description, price, image_url, stock, rating, reviews, category)
values
('خاتم الزفاف الذهبي', 'Golden Wedding Ring', 'خاتم فاخر بتصميم أنيق للمناسبات الخاصة.', 1500, '/placeholder.svg?height=300&width=300', 5, 4.8, 128, 'خواتم'),
('عقد الأميرة', 'Princess Necklace', 'عقد أنيق مستوحى من التصاميم الملكية.', 2800, '/placeholder.svg?height=300&width=300', 3, 4.9, 95, 'عقود'),
('أساور الماس', 'Diamond Bracelets', 'أساور براقة تناسب الإطلالات الراقية.', 3200, '/placeholder.svg?height=300&width=300', 2, 4.7, 67, 'أساور'),
('أقراط الفضة', 'Silver Earrings', 'أقراط فضية خفيفة وعملية.', 800, '/placeholder.svg?height=300&width=300', 8, 4.6, 142, 'أقراط'),
('خاتم الياقوت', 'Sapphire Ring', 'خاتم بحجر ياقوت مميز.', 2200, '/placeholder.svg?height=300&width=300', 1, 4.9, 83, 'خواتم'),
('تاج العروس', 'Bridal Crown', 'تاج فاخر لإطلالة العروس.', 4500, '/placeholder.svg?height=300&width=300', 0, 5.0, 45, 'إكسسوارات')
on conflict do nothing;
